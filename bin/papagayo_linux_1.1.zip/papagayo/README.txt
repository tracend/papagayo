------------------------------------------------
Linux Notes
------------------------------------------------

------------------------------------------------
System Requirements
------------------------------------------------

The requirements to run Papagayo are the following:

Python 2.4 - Papagayo is written in Python. Older versions of Python may work, but 2.4 is recommended.
wxPython 2.6 - There is a good chance this is not already installed on your system. Get it here: http://www.wxpython.org/
glibc 2.2.5 - Your system should have this version or later.
gcc 3.2 - It's not clear yet if the compiler version really matters, but this is what some Papagayo accessory libraries are compiled with.

------------------------------------------------
Installing
------------------------------------------------

To install Papagayo on your Linux system, all you should need to do is to decompress the package and place it wherever you like on your system. To launch Papagayo, run the script called 'papagayo' included in the download. If you run into problems, you may need to make small adjustments to that startup script.

------------------------------------------------
Audio Issues
------------------------------------------------

To make full use of Papagayo, you really need to hear the audio files you're working with. However, depending on your setup you may need to go through some additional audio configuration steps. If you see an audio waveform in the timeline but you don't hear anything when you play it back, try the following steps:

1) First, make sure that audio is working on your computer. Can other programs play back audio files? (It can sometimes be tricky to get audio working on Linux.)

2) Next, check to see if an audio device is present. Enter the following command in a terminal window:

> ls /dev/dsp*

You should see one or more devices listed.

3) Next, check to see if another process has exclusive access to the audio device. Enter the following command:

> fuser /dev/dsp

If the audio device is free, then nothing should print out. If another process is using the audio device, a number will come back - the number of that process. Both KDE and Gnome have their own little sound server deamons that start when you log on - the process is likely one of those. Try turning it off. Exactly how to do this depends on your system, but here's an example with Ubuntu: Select the System->Preferences->Sound menu command, and in the control panel that comes up, turn off "Enable sound server startup". Try logging out and back in and see if Papagayo plays audio now.

4) If that didn't fix it, try the following command again:

> fuser /dev/dsp

If a process is still listed as using the audio device, you can find out the name of the process by using pgrep. Try the following command (with your actual username):

> pgrep -l -u username

Look in the list for a number matching the process you found in step 4. The name of the process may give you a clue as to what program it is. Try to disable that program at startup. If you can't figure out which process is accessing the audio device, you can try to kill it anyway, using the following command:

> kill -9 `fuser /dev/dsp`

Try starting Papagayo up again and playing a sound. If that solved the problem, you can add the command above to the 'papagayo' startup script.

------------------------------------------------
Feedback
------------------------------------------------

We want your feedback. Please tell us about your experience with Papagayo on Linux. Whatever's on your mind, we want to hear it. Please send your feedback about the Linux version of Papagayo to:

support@lostmarble.com



http://www.lostmarble.com
